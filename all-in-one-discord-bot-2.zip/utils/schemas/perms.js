module.exports = () => {
    cmd: {
        _id: String
    }
}