module.exports = ( ) => {
    user_id: {
        _id: {
            logs: Number
        }
    }
}